package com.bjss.com.bjss.pricing.processors;

import com.bjss.com.bjss.pricing.AvailableOffers;
import com.bjss.com.bjss.pricing.offers.Offer;
import com.bjss.com.bjss.pricing.pojos.Basket;

/*
 * This class applies the available offers,
 * then calls the next processor which is total calculator
 */
public class OffersProcessor extends BasketProcessor {

	/*
	 * (non-Javadoc)
	 * @see com.bjss.com.bjss.pricing.processors.BasketProcessor#processRequest(com.bjss.com.bjss.pricing.pojos.Basket)
	 * 
	 * Offers are fetched and applied. Offers classes followed strategy design pattern to some extent 
	 * to fetch the respective offering algorithm during the run time based on the offer type.
	 * 
	 * In future if we wanted to use completely different offer  implementation, we can use without
	 * changing the processors in the chain
	 */
	@Override
	public void processRequest(Basket basket) {

		
		for(Offer offer:AvailableOffers.OFFERS){
			offer.applyThisOffer(basket);
		}
		nextProcessor.processRequest(basket);
	
	}

}
