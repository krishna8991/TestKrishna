package com.bjss.com.bjss.pricing.offers;

import java.math.BigDecimal;

import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;

/*
 * This class represents the simple percentage based discounts.
 * Similarly, we can create value based discount class or product based 
 * (scenario where the product is offered as free item instead of discounting the price)
 * 
 * This class represents first offer - Apples have a 10% discount off their normal price
 */
public class PercentageOffer extends Offer {

	BigDecimal percentageInFraction;
	Product product;

	public BigDecimal getPercentageInFraction() {
		return percentageInFraction;
	}

	public void setPercentageInFraction(BigDecimal percentageInFraction) {
		this.percentageInFraction = percentageInFraction;
	}

	public PercentageOffer(BigDecimal percentage, Product product, String description) {
		super(description);
		this.percentageInFraction = percentage;
		this.product = product;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public void applyThisOffer(Basket basket) {
		for (Product productFromBasket : basket.getProductsAndQuantity().keySet()) {
			if (this.product.getName().equals(productFromBasket.getName())) {

				BigDecimal discountPerUnit = productFromBasket.getPrice().multiply(percentageInFraction);
				BigDecimal quantity = new BigDecimal(basket.getProductsAndQuantity().get(productFromBasket));
				BigDecimal totalDiscount = basket.getSavedAmount().add(discountPerUnit).multiply(quantity);
				basket.setSavedAmount(totalDiscount);

				if (basket.getAppliedOffers().keySet().contains(this)) {
					basket.getAppliedOffers().put(this, basket.getAppliedOffers().get(this).add(totalDiscount));
				} else {
					basket.getAppliedOffers().put(this, totalDiscount);
				}

			}
		}

	}
}
