package com.bjss.com.bjss.pricing;

import java.util.ArrayList;
import java.util.List;

import com.bjss.com.bjss.pricing.offers.Offer;

public class AvailableOffers {

	public static final List <Offer> OFFERS = new ArrayList<Offer>();
}
