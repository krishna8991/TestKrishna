package com.bjss.com.bjss.pricing.enums;

public enum MeasurmentUnit {
	TIN, LOAF, BOTTLE, BAG
}
