package com.bjss.com.bjss.pricing.processors;

import java.math.BigDecimal;
import java.util.Map.Entry;

import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;

/*
 * It calculates the sub total and calls the next step 
 * which is Offers implementation
 */
public class BasketSubTotalCalculator extends BasketProcessor {

	@Override
	public void processRequest(Basket basket) {
		BigDecimal subTotal = BigDecimal.ZERO;
		for (Entry<Product, Integer> ProductAndQuantity : basket.getProductsAndQuantity().entrySet()) {
			subTotal = subTotal.add(
					(ProductAndQuantity.getKey().getPrice().multiply(new BigDecimal(ProductAndQuantity.getValue()))));
		}
		basket.setSubTotal(subTotal);

		nextProcessor.processRequest(basket);
	}
}
