package com.bjss.com.bjss.pricing.builders;

import java.math.BigDecimal;
import java.util.Currency;

import com.bjss.com.bjss.pricing.enums.MeasurmentUnit;
import com.bjss.com.bjss.pricing.pojos.Product;

public class ProductBuilderImpl implements ProductBuilder {

	private Product product;

	public ProductBuilderImpl(String name) {
		product = new Product(name);
	}

/*	public ProductBuilder setName(String name) {
		product.setName(name);
		return this;
	}
*/
	public ProductBuilder setPrice(BigDecimal price) {

		product.setPrice(price);
		return this;
	}

	public ProductBuilder setMeasurmentUnit(MeasurmentUnit measurmentUnit) {

		product.setMeasurmentUnit(measurmentUnit);
		return this;
	}

	public ProductBuilder setCurrency(Currency currency) {
		product.setCurrency(currency);

		return this;
	}

	public Product create() {

		return product;
	}
}
