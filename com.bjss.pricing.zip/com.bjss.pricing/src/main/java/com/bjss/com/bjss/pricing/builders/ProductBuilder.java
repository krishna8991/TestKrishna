package com.bjss.com.bjss.pricing.builders;

import java.math.BigDecimal;
import java.util.Currency;

import com.bjss.com.bjss.pricing.enums.MeasurmentUnit;
import com.bjss.com.bjss.pricing.pojos.Product;

/*
 * It is not one of the primary functionality of the 
 * application. It is used for loading the static data
 */
public interface ProductBuilder {

	// ProductBuilder setName(String name);
	ProductBuilder setPrice(BigDecimal price);

	ProductBuilder setMeasurmentUnit(MeasurmentUnit measurmentUnit);

	ProductBuilder setCurrency(Currency currency);

	Product create();
}
