package com.bjss.com.bjss.pricing.processors;

import com.bjss.com.bjss.pricing.pojos.Basket;
/*
 * It calculates the total amount and passes the request
 * to next processor for out put display on the console
 */
public class BasketTotalCalculator extends BasketProcessor {

	@Override
	public void processRequest(Basket basket) {
		basket.setTotal(basket.getSubTotal().subtract(basket.getSavedAmount()));
		nextProcessor.processRequest(basket);
	}

}
