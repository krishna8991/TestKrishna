package com.bjss.com.bjss.pricing.offers;

import java.math.BigDecimal;



import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;

/*
 * This extension and override of PercentageOffer class.
 * It represents in scenario when one product is brought, different product's price is reduced
 * 
 * For, eg : Buy a bottle of milk. get discount on bread.
 */
public class PercentageOfferOnDifferetProduct extends PercentageOffer {

	Product discountProduct;

	public PercentageOfferOnDifferetProduct(BigDecimal percentage, Product product, Product discountProduct, String description) {
		super(percentage, product, description);
		this.discountProduct = discountProduct;
	}

	public Product getDiscountProduct() {
		return discountProduct;
	}

	public void setDiscountProduct(Product discountProduct) {
		this.discountProduct = discountProduct;
	}

/*	public BigDecimal getDicsountedPrice() {
		return productAllowedForDiscount.getPrice().multiply(percentageInFraction);
	}
*/
	/*
	 * (non-Javadoc)
	 * @see com.bjss.com.bjss.pricing.offers.PercentageOffer#applyThisOffer(com.bjss.com.bjss.pricing.pojos.Basket)
	 */
	@Override
	public void applyThisOffer(Basket basket) {	
		
	}
}
