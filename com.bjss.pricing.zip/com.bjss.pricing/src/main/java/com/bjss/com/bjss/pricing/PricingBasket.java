package com.bjss.com.bjss.pricing;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Locale;
import java.util.Scanner;

import org.apache.commons.lang.WordUtils;
import org.joda.time.DateTime;

import com.bjss.com.bjss.pricing.builders.ProductBuilderImpl;
import com.bjss.com.bjss.pricing.enums.MeasurmentUnit;
import com.bjss.com.bjss.pricing.offers.MultiBuyPercentageOfferOnDifferetProduct;
import com.bjss.com.bjss.pricing.offers.Offer;
import com.bjss.com.bjss.pricing.offers.PercentageOffer;
import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;
import com.bjss.com.bjss.pricing.processors.BasketSubTotalCalculator;
import com.bjss.com.bjss.pricing.processors.BasketTotalCalculator;
import com.bjss.com.bjss.pricing.processors.OffersProcessor;
import com.bjss.com.bjss.pricing.processors.OutputDisplayProcessors;

import com.bjss.com.bjss.pricing.validator.Validator;

public class PricingBasket {

	public static final String ERROR = "Apples, Bread, Soup and Milk are only the available products in stock";

	public static final String PRICE_BASKET = "PriceBasket";
	public static boolean rerun = true; // To keep running the App

	// This is persistent data usually read from DB. Loading this data
	// initially.
	static {
		Product apples = new ProductBuilderImpl("Apples").setPrice(new BigDecimal("1.00"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.BAG).create();
		Product bread = new ProductBuilderImpl("Bread").setPrice(new BigDecimal("0.80"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.LOAF).create();
		Product soup = new ProductBuilderImpl("Soup").setPrice(new BigDecimal("0.65"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.TIN).create();
		Product milk = new ProductBuilderImpl("Milk").setPrice(new BigDecimal("1.30"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.BOTTLE).create();

		Stock.AVAILABLE_PRODUCTS.put(apples.getName(), apples);
		Stock.AVAILABLE_PRODUCTS.put(bread.getName(), bread);
		Stock.AVAILABLE_PRODUCTS.put(soup.getName(), soup);
		Stock.AVAILABLE_PRODUCTS.put(milk.getName(), milk);

		String applesOffer = "Apples  10% off";
		DateTime applesOfferValidFrom = new DateTime(2017, 6, 12, 12, 0, 0, 0);
		DateTime applesOfferValidTo = applesOfferValidFrom.plusDays(7);
		Offer applesPriceDiscount = new PercentageOffer(new BigDecimal(10).divide(new BigDecimal(100)),
				Stock.AVAILABLE_PRODUCTS.get("Apples"), applesOffer);
		applesPriceDiscount.setValidFrom(applesOfferValidFrom);
		applesPriceDiscount.setValidTo(applesOfferValidTo);
		String soupAndBreadOffer = "2 tin of soup and a loaf of bread for half price";
		Offer multiSoupBuyBreadOffer = new MultiBuyPercentageOfferOnDifferetProduct(
				new BigDecimal(50).divide(new BigDecimal(100)), Stock.AVAILABLE_PRODUCTS.get("Soup"),
				Stock.AVAILABLE_PRODUCTS.get("Bread"), 2, 1, soupAndBreadOffer);

		AvailableOffers.OFFERS.add(applesPriceDiscount);
		AvailableOffers.OFFERS.add(multiSoupBuyBreadOffer);
	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		while (rerun) {
			System.out.print(PRICE_BASKET+ "  ");

			String combinedItems = scanner.nextLine().trim();

			if (combinedItems.length() == 0) { //Enter empty string to stop the application
				rerun = false;
			} else {

				processBasket(combinedItems);

			}

		}
		scanner.close();

	}

	/*
	 * This method has the complete logic of processing the Basket. 
	 * It follows the chain of responsibility with Basket as request in the chain
	 */
	private static void processBasket(String combinedItems) {

		String[] items = WordUtils.capitalizeFully(combinedItems).split(("\\s+")); //Converting into Camel case and splitting the string
		
		Validator validator = new Validator();

		BasketSubTotalCalculator basketSubTotalCalculator = new BasketSubTotalCalculator();
		OffersProcessor offersProcessor = new OffersProcessor();
		BasketTotalCalculator basketTotalCalculator = new BasketTotalCalculator();
		OutputDisplayProcessors outputDisplayProcessors = new OutputDisplayProcessors();
		
		basketSubTotalCalculator.setNextProcessor(offersProcessor);
		offersProcessor.setNextProcessor(basketTotalCalculator);
		basketTotalCalculator.setNextProcessor(outputDisplayProcessors);		

		Basket basket;
		if (validator.validate(items)) {
			basket = new Basket(items);			
			basketSubTotalCalculator.processRequest(basket);
		} else {
			throw new IllegalArgumentException(ERROR);
		}

	}

}
