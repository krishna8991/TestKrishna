package com.bjss.com.bjss.pricing.offers;

import java.math.BigDecimal;
import java.util.Set;

import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;

/*
 * This class is extends and overrides PercentageOfferOnDifferetProduct class.
 * It represents the offers which are of multi-buy of one kind of produc  and price reduction on different/same product
 * 
 * This represents 2 tin of soup and a loaf bread for half price offer. Instead of one loaf of bread, it can handle multiple.
 */
public class MultiBuyPercentageOfferOnDifferetProduct extends PercentageOfferOnDifferetProduct {

	int productQuantity; // 2 Tins of Soup
	int discountProductQuantity; // This is maximum quantity allowed for
									// discount - in the given problem, it is
									// one load of bread

	public MultiBuyPercentageOfferOnDifferetProduct(BigDecimal percentage, Product product,
			Product productAllowedForDiscount, int productQuantity, int discountProductQuantity, String description) {
		super(percentage, product, productAllowedForDiscount, description);

		this.discountProductQuantity = discountProductQuantity;
		this.productQuantity = productQuantity;

	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public int getDiscountProductQuantity() {
		return discountProductQuantity;
	}

	public void setDiscountProductQuantity(int discountProductQuantity) {
		this.discountProductQuantity = discountProductQuantity;
	}

	@Override
	public void applyThisOffer(Basket basket) {

		Set<Product> productsInBasket = basket.getProductsAndQuantity().keySet();
		BigDecimal discount = BigDecimal.ZERO;
		for (Product productFromBasket : productsInBasket) {
			int productQuantityInBasket = basket.getProductsAndQuantity().get(productFromBasket);
			// If the offer product is in the basket and its quantity is greater
			// than the quantity in the offer and if the discount eligible
			// product is in the basket (It is to say if the basket contains 2
			// tins of soup and a loaf of bread)
			if (checkForOfferEligiblity(productFromBasket, productsInBasket, productQuantityInBasket)) {
				int discountProductQuantityInBasket = basket.getProductsAndQuantity().get(discountProduct);
				//For one bread
				BigDecimal discountPerUnit = discountProduct.getPrice().multiply(percentageInFraction);
				// In Soup and Bread offer discountProductQuantity would be 1
				int totalEligibleUnits = productQuantityInBasket / this.productQuantity * this.discountProductQuantity; 
				
				// If the Basket contains more loafs of bread than maximum allowed loafs for discount
				if (discountProductQuantityInBasket > totalEligibleUnits) {
					discount = discountPerUnit.multiply(new BigDecimal(totalEligibleUnits));
				} else {
					discount = discountPerUnit.multiply(new BigDecimal(discountProductQuantityInBasket));
				}

				if (basket.getAppliedOffers().keySet().contains(this)) {
					basket.getAppliedOffers().put(this, basket.getAppliedOffers().get(this).add(discount));
				} else {
					basket.getAppliedOffers().put(this, discount);
				}

			}

		}
		basket.setSavedAmount(basket.getSavedAmount().add(discount));

	}

	private boolean checkForOfferEligiblity(Product productFromBasket, Set<Product> productsInBasket,
			int productQuantityInBasket) {
		return productFromBasket.getName().equals(this.product.getName())
				&& productQuantityInBasket >= this.productQuantity && productsInBasket.contains(this.discountProduct);

	}
}
