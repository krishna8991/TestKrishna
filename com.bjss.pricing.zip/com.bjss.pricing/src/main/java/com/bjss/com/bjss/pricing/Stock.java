package com.bjss.com.bjss.pricing;

import java.util.HashMap;
import java.util.Map;

import com.bjss.com.bjss.pricing.pojos.Product;

public class Stock {

	public static final Map<String, Product> AVAILABLE_PRODUCTS = new HashMap<String, Product>();

}
