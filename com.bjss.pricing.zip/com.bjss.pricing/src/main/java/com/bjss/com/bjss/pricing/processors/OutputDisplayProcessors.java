package com.bjss.com.bjss.pricing.processors;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import com.bjss.com.bjss.pricing.offers.Offer;
import com.bjss.com.bjss.pricing.pojos.Basket;

public class OutputDisplayProcessors extends BasketProcessor {

	@Override
	public void processRequest(Basket basket) {
		System.out.println("Subtotal: "+basket.getCurrency().getSymbol()+basket.getSubTotal().setScale(2));
		if(basket.getAppliedOffers().size()>0){
			for(Map.Entry<Offer, BigDecimal> entry: basket.getAppliedOffers().entrySet()){
				System.out.println(entry.getKey().getDescription()+": - "+basket.getCurrency().getSymbol()+entry.getValue().setScale(2));
			}
			
		}else {
			System.out.println("(No offers availalbe)");
		}
		System.out.println("Total  "+basket.getCurrency().getSymbol()+ basket.getTotal().setScale(2));
	}

}
