package com.bjss.com.bjss.pricing.pojos;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.bjss.com.bjss.pricing.Stock;
import com.bjss.com.bjss.pricing.offers.Offer;

/*
 * Basket object is the primary one which encapsulates 
 * the data needed for processing and console output
 */
public class Basket {

	BigDecimal total;
	BigDecimal subTotal;
	BigDecimal savedAmount = BigDecimal.ZERO;
	Currency currency = Currency.getInstance(Locale.UK);
	Map<Product, Integer> productsAndQuantity = new HashMap<Product, Integer>();
	Map<Offer, BigDecimal> appliedOffers = new HashMap<Offer, BigDecimal>();

	/*
	 * Products are copied from available products collection. It was not required to create new objects
	 * Product objects are used only reading and used without writing(Immutable way, even though Product is not made immutable)
	 */
	public Basket(String[] items) {
		for (String item : items) {
			Product product = Stock.AVAILABLE_PRODUCTS.get(item);
			if (productsAndQuantity.keySet().contains(product)) {
				productsAndQuantity.put(product, productsAndQuantity.get(product) + 1);
			} else {
				productsAndQuantity.put(product, 1);
			}
		}
	}

	public Map<Product, Integer> getProductsAndQuantity() {
		return productsAndQuantity;
	}

	public void setProductsAndQuantity(Map<Product, Integer> productsAndQuantity) {
		this.productsAndQuantity = productsAndQuantity;
	}

	public BigDecimal getSavedAmount() {
		return savedAmount;
	}

	public void setSavedAmount(BigDecimal savedAmount) {
		this.savedAmount = savedAmount;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}

	public Map<Offer, BigDecimal> getAppliedOffers() {
		return appliedOffers;
	}

	public void setAppliedOffers(Map<Offer, BigDecimal> appliedOffers) {
		this.appliedOffers = appliedOffers;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

}
