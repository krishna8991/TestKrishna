package com.bjss.com.bjss.pricing.offers;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;

import com.bjss.com.bjss.pricing.AvailableOffers;
import com.bjss.com.bjss.pricing.Stock;
import com.bjss.com.bjss.pricing.builders.ProductBuilderImpl;
import com.bjss.com.bjss.pricing.enums.MeasurmentUnit;
import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;

@RunWith(MockitoJUnitRunner.class)
public class MultiBuyPercentageOfferOnDifferetProductTest {
	
	MultiBuyPercentageOfferOnDifferetProduct offer;
	@Mock
	Product productOnOffer;
	
	Product productEligibleForDiscount;
	//@Mock
	Basket basket;
	

	//Fill the stock and available offers
	@Before
	public void setup() throws Exception {		
			//Stock
			Product apples = new ProductBuilderImpl("Apples").setPrice(new BigDecimal("1.00"))
					.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.BAG).create();
			Product bread = new ProductBuilderImpl("Bread").setPrice(new BigDecimal("0.80"))
					.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.LOAF).create();
			Product soup = new ProductBuilderImpl("Soup").setPrice(new BigDecimal("0.65"))
					.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.TIN).create();
			Product milk = new ProductBuilderImpl("Milk").setPrice(new BigDecimal("1.30"))
					.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.BOTTLE).create();

			Stock.AVAILABLE_PRODUCTS.put(apples.getName(), apples);
			Stock.AVAILABLE_PRODUCTS.put(bread.getName(), bread);
			Stock.AVAILABLE_PRODUCTS.put(soup.getName(), soup);
			Stock.AVAILABLE_PRODUCTS.put(milk.getName(), milk);
			
			//Offers
			String applesOffer = "Apples  10% off";
			DateTime applesOfferValidFrom = new DateTime(2017, 6, 12, 12, 0, 0, 0);
			DateTime applesOfferValidTo = applesOfferValidFrom.plusDays(7);
			Offer applesPriceDiscount = new PercentageOffer(new BigDecimal(10).divide(new BigDecimal(100)),
					Stock.AVAILABLE_PRODUCTS.get("Apples"), applesOffer);
			applesPriceDiscount.setValidFrom(applesOfferValidFrom);
			applesPriceDiscount.setValidTo(applesOfferValidTo);
			String soupAndBreadOffer = "2 tin of soup and a loaf of bread for half price";
			Offer multiSoupBuyBreadOffer = new MultiBuyPercentageOfferOnDifferetProduct(
					new BigDecimal(50).divide(new BigDecimal(100)), Stock.AVAILABLE_PRODUCTS.get("Soup"),
					Stock.AVAILABLE_PRODUCTS.get("Bread"), 2, 1, soupAndBreadOffer);

			AvailableOffers.OFFERS.add(applesPriceDiscount);
			AvailableOffers.OFFERS.add(multiSoupBuyBreadOffer);

	}
	
	/*
	 * This is to test Soup and Bread offer - 
	 */
	@Test
	public void testApplyThisOffer1(){
		
		//Basket containing 2 tin soup and a load of bread
		basket = new Basket(new String [] {"Soup", "Soup", "Bread"});
		
		/*Map<Product, Integer> productsAndQuantity = new HashMap<Product, Integer>();		
		productsAndQuantity.put(Stock.AVAILABLE_PRODUCTS.get("Soup"), 2);
		productsAndQuantity.put(Stock.AVAILABLE_PRODUCTS.get("Bread"), 1);*/

		/*when(basket.getProductsAndQuantity()).thenReturn(productsAndQuantity);
		when(basket.getSavedAmount()).thenReturn(BigDecimal.ZERO);*/
		productEligibleForDiscount=Stock.AVAILABLE_PRODUCTS.get("Bread");
		//when(productEligibleForDiscount.getPrice()).thenReturn(Stock.AVAILABLE_PRODUCTS.get("Bread").getPrice());
		when(productOnOffer.getName()).thenReturn(Stock.AVAILABLE_PRODUCTS.get("Soup").getName());
		//when(productEligibleForDiscount.getName()).thenReturn(Stock.AVAILABLE_PRODUCTS.get("Bread").getName());
		
		String offerDiscription =  "Soup and Bread offer";
		BigDecimal percentage= new BigDecimal(50).divide(new BigDecimal(100));
		int productQuantity = 2;
		int discountedProductQuantity =1;
		offer= new MultiBuyPercentageOfferOnDifferetProduct(percentage, productOnOffer, productEligibleForDiscount , productQuantity, discountedProductQuantity, offerDiscription);
		
		offer.applyThisOffer(basket);
		
		assertEquals(basket.getSavedAmount(), ((MultiBuyPercentageOfferOnDifferetProduct)AvailableOffers.OFFERS.get(1)).getPercentageInFraction().multiply(productEligibleForDiscount.getPrice()));		
		
		
	}
	/*
	 * Test when there is no applicable offer 
	 * 
	 */
	
	@Test
	public void testApplyThisOffer(){
		basket = new Basket(new String [] {"Milk", "Soup", "Bread"});
		productEligibleForDiscount=Stock.AVAILABLE_PRODUCTS.get("Bread");
		when(productOnOffer.getName()).thenReturn(Stock.AVAILABLE_PRODUCTS.get("Soup").getName());
		String offerDiscription =  "Soup and Bread offer";
		BigDecimal percentage= new BigDecimal(50).divide(new BigDecimal(100));
		int productQuantity = 2;
		int discountedProductQuantity =1;
		offer= new MultiBuyPercentageOfferOnDifferetProduct(percentage, productOnOffer, productEligibleForDiscount , productQuantity, discountedProductQuantity, offerDiscription);
		offer.applyThisOffer(basket);
		
		assertEquals(basket.getSavedAmount(), BigDecimal.ZERO);
	}
}
