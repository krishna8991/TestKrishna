package com.bjss.com.bjss.pricing;

import com.bjss.com.bjss.pricing.enums.OfferType;

public class Offer {
	
	

	public Offer(String product, OfferType offerType) {

	}
}



// Strategy patters for applying offers on Basket