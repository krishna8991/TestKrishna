package com.bjss.com.bjss.pricing;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Locale;
import java.util.Scanner;

import org.apache.commons.lang.WordUtils;

import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;
import com.bjss.com.bjss.pricing.validator.Validator;

/**
 * Hello world!
 *
 */
public class App {
	
	public static final String ERROR ="Apples, Bread, Soup and Milk are only the available products in stock";

	public static final String PRICE_BASKET = "PriceBasket";
	public static boolean rerun = true;

	static {
		Product apples = new ProductBuilderImpl("Apples").setPrice(new BigDecimal("1.00"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.BAG).create();
		Product bread = new ProductBuilderImpl("Bread").setPrice(new BigDecimal("0.80"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.LOAF).create();
		Product soup = new ProductBuilderImpl("Soup").setPrice(new BigDecimal("0.65"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.TIN).create();
		Product milk = new ProductBuilderImpl("Milk").setPrice(new BigDecimal("1.30"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.BOTTLE).create();

		Stock.availbleProducts.put(apples.getName(), apples);
		Stock.availbleProducts.put(bread.getName(), bread);
		Stock.availbleProducts.put(soup.getName(), soup);
		Stock.availbleProducts.put(milk.getName(), milk);
	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		while (rerun) {
			System.out.print(PRICE_BASKET);

			String combinedItems = scanner.nextLine().trim();

			if (combinedItems.length() == 0) {
				rerun = false;
			} else {

				processBasket(combinedItems);
				
			}

		}

		scanner.close();
	
	}

	private static void processBasket(String combinedItems){
		
		String [] items = WordUtils.capitalizeFully(combinedItems).split(("\\s+"));
		Validator validator = new Validator();
		Basket basket;
		if(validator.validate(items)){
			basket = new Basket(items);
			
		} else {
			throw new IllegalArgumentException(ERROR);
		}
		
	
	}

}
