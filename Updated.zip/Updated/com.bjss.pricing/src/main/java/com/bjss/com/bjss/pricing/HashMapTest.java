package com.bjss.com.bjss.pricing;

import java.util.HashMap;
import java.util.Map;

public class HashMapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map <String, Integer>testMap = new HashMap<String, Integer>();
		testMap.put("Apples", 1);
		testMap.put("Bread", 2);
		testMap.put("Soup", 2);
		
		System.out.println(testMap.get("Apples"));
		System.out.println(testMap.get("Bread"));
		System.out.println(testMap.get("Soup"));
	}

}
