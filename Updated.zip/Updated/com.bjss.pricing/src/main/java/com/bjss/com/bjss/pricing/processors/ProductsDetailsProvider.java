package com.bjss.com.bjss.pricing.processors;

import com.bjss.com.bjss.pricing.Stock;
import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;

public class ProductsDetailsProvider extends BasketProcessor {

	@Override
	public void processRequest(Basket basket) {
		for (Product product : basket.getProductsAndQuantity().keySet()) {
			Product sku = Stock.availbleProducts.get(product.getName());
			product.setCurrency(sku.getCurrency());
			product.setMeasurmentUnit(sku.getMeasurmentUnit());
			product.setPrice(sku.getPrice());
			product.setId(sku.getId());
		}

	}

}
