package com.bjss.com.bjss.pricing.validator;

import java.util.Set;

import com.bjss.com.bjss.pricing.Stock;

public class Validator {

	public boolean validate(String[] items) {

		boolean result = false;

		Set<String> itemsInStock = Stock.availbleProducts.keySet();

		for (String item : items) {
			if (!itemsInStock.contains(item)) {
				result = true;
				break;
			}
		}

		return result;
	}

}
