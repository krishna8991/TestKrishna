package com.bjss.com.bjss.pricing;

import java.math.BigDecimal;
import java.util.Currency;

import com.bjss.com.bjss.pricing.pojos.Product;

public interface ProductBuilder {
	
	//ProductBuilder setName(String name);
	ProductBuilder setPrice (BigDecimal price);
	ProductBuilder setMeasurmentUnit(MeasurmentUnit measurmentUnit);
	ProductBuilder setCurrency (Currency currency);

	Product create();
}
