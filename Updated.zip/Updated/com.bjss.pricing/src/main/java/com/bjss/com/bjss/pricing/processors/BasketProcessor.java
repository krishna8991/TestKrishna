package com.bjss.com.bjss.pricing.processors;

import com.bjss.com.bjss.pricing.pojos.Basket;

public abstract class BasketProcessor {

	protected BasketProcessor nextProcessor;

	public void setNextProcessor(BasketProcessor nextProcessor) {
		this.nextProcessor = nextProcessor;
	}

	public abstract void processRequest(Basket basket);
}
