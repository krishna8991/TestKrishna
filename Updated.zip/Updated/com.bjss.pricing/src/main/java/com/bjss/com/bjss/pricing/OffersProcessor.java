package com.bjss.com.bjss.pricing;

public class OffersProcessor {
	
	// OfferStr
//	OfferStrategy offerStrategy
	
}
