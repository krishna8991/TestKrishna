package com.bjss.com.bjss.pricing;

import java.util.List;

import com.bjss.com.bjss.pricing.pojos.Product;
import com.bjss.com.bjss.pricing.processors.BasketProcessor;

public class ValidateProcessor extends BasketProcessor {
/*
	@Override
	public void processRequest(List<Product> request) {
		
		if(Stock.availbleProducts.keySet().contains(request.getName()))
		{
			nextProcessor.processRequest(request);
		}
			
		
	}*/

	@Override
	public void processRequest(List<Product> request) {

		//for()
		
	}

}
