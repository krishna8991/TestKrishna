package com.bjss.com.bjss.pricing.processors;

import com.bjss.com.bjss.pricing.pojos.Basket;

public class BasketTotalCalculator extends BasketProcessor{

	@Override
	public void processRequest(Basket basket) {
		// TODO Auto-generated method stub
		
	}

}
