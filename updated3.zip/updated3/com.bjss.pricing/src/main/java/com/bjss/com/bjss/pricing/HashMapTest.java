package com.bjss.com.bjss.pricing;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;

public class HashMapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map <String, Integer>testMap = new HashMap<String, Integer>();
		testMap.put("Apples", 1);
		testMap.put("Bread", 2);
		testMap.put("Soup", 2);
		
		System.out.println(testMap.get("Apples"));
		System.out.println(testMap.get("Bread"));
		System.out.println(testMap.get("Soup"));
		
		double num = 0.5267;

		NumberFormat defaultFormat = NumberFormat.getPercentInstance();
		//defaultFormat.form
		System.out.println(defaultFormat.format(0.1));
		
		BigDecimal testBD= new BigDecimal("23.45");
		BigDecimal testBD1 = testBD.add(new BigDecimal("45.12"));
		
		System.out.println("testBD>>"+testBD);
		System.out.println("testBD1>>"+testBD1);
		
	}
	

}
