package com.bjss.com.bjss.pricing.validator;

import java.util.Set;

import com.bjss.com.bjss.pricing.Stock;

public class Validator {

	public boolean validate(String[] items) {

		boolean result = true;

		Set<String> itemsInStock = Stock.AVAILABLE_PRODUCTS.keySet();

		for (String item : items) {
			if (!itemsInStock.contains(item)) {
				result = false;
				break;
			}
		}

		return result;
	}

}
