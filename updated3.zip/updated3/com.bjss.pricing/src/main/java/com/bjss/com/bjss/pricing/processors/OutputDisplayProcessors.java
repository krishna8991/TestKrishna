package com.bjss.com.bjss.pricing.processors;

import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Offer;

public class OutputDisplayProcessors extends BasketProcessor {

	@Override
	public void processRequest(Basket basket) {
		System.out.println("Subtotal: "+basket.getSubTotal());
		if(basket.getAppliedOffers().size()>0){
			for(Offer offer:basket.getAppliedOffers()){
				System.out.println(offer.getDescription());
			}
		}else {
			System.out.println("No offers availalbe");
		}
		System.out.println("Total  "+ basket.getTotal());
	}

}
