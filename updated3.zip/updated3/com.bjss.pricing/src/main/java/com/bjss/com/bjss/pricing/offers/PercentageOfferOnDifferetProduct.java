package com.bjss.com.bjss.pricing.offers;

import java.math.BigDecimal;



import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;

public class PercentageOfferOnDifferetProduct extends PercentageOffer {

	Product discountProduct;

	public PercentageOfferOnDifferetProduct(BigDecimal percentage, Product product, Product discountProduct, String description) {
		super(percentage, product, description);
		this.discountProduct = discountProduct;
	}

	public Product getDiscountProduct() {
		return discountProduct;
	}

	public void setDiscountProduct(Product discountProduct) {
		this.discountProduct = discountProduct;
	}

/*	public BigDecimal getDicsountedPrice() {
		return productAllowedForDiscount.getPrice().multiply(percentageInFraction);
	}
*/
	
	@Override
	public void applyThisOffer(Basket basket) {	
		
	}
}
