package com.bjss.com.bjss.pricing.offers;

import java.math.BigDecimal;
import java.util.Set;

import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Product;

public class MultiBuyPercentageOfferOnDifferetProduct extends PercentageOfferOnDifferetProduct {

	int productQuantity;
	int discountProductQuantity; //This is maximum quantity allowed for discount
	

	public MultiBuyPercentageOfferOnDifferetProduct(BigDecimal percentage, Product product,
			Product productAllowedForDiscount, int productQuantity, int discountProductQuantity, String description) {
		super(percentage, product, productAllowedForDiscount, description);

		this.discountProductQuantity = discountProductQuantity;
		this.productQuantity = productQuantity;

	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public int getDiscountProductQuantity() {
		return discountProductQuantity;
	}

	public void setDiscountProductQuantity(int discountProductQuantity) {
		this.discountProductQuantity = discountProductQuantity;
	}
	
/*	public BigDecimal getDicsountedPrice(BigDecimal originalPrice) {
		return originalPrice.multiply(percentageInFraction);
	}*/

	@Override
	public void applyThisOffer(Basket basket) {	
		
		Set<Product> productsInBasket = basket.getProductsAndQuantity().keySet();
		BigDecimal discount=BigDecimal.ZERO;
		for(Product productFromBasket:productsInBasket){
			int  productQuantityInBasket= basket.getProductsAndQuantity().get(productFromBasket);			
			//If the offer product is in the basket and its quantity is greater than the quantity in the offer and if the discount eligible product is in the basket
			if(productFromBasket.getName().equals(this.product.getName())&&productQuantityInBasket>this.productQuantity&&productsInBasket.contains(this.discountProduct)){
				//Calculate the discount				
				int discountProductQuantityInBasket = basket.getProductsAndQuantity().get(discountProduct);				
				//If the discount product quantity in the Basket is greater than allowed quantity 
				BigDecimal discountPerUnit= discountProduct.getPrice().subtract(discountProduct.getPrice().multiply(percentageInFraction));
				if (discountProductQuantityInBasket>discountProductQuantity){					
					discount = discountPerUnit.multiply(new BigDecimal(discountProductQuantity));
				} else {
					discount = discountPerUnit.multiply(new BigDecimal(discountProductQuantityInBasket));
				}				
			
			}
			
		
		}
		basket.getAppliedOffers().add(this);
		basket.setSavedAmount(basket.getSavedAmount().add(discount));
		
		
	}
}
