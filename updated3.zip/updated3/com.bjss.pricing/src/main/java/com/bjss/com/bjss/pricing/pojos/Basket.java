package com.bjss.com.bjss.pricing.pojos;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bjss.com.bjss.pricing.Stock;

public class Basket {

	Map<Product, Integer> productsAndQuantity = new HashMap<Product, Integer>();
	Set<Offer> appliedOffers = new HashSet<Offer>();
	
	BigDecimal total;
	BigDecimal subTotal;
	BigDecimal savedAmount=BigDecimal.ZERO;

	// Contains the list of items
	// Contains OfferStrategy
	// sub total
	// total
	// discount

	public Basket(String[] items) {
		for (String item : items) {
			Product product = Stock.AVAILABLE_PRODUCTS.get(item);
			if (productsAndQuantity.keySet().contains(product)) {
				productsAndQuantity.put(product, productsAndQuantity.get(product)+1);				
			} else {
				productsAndQuantity.put(product, 1);
			}
		}
	}
	
	

	public Map<Product, Integer> getProductsAndQuantity() {
		return productsAndQuantity;
	}

	public void setProductsAndQuantity(Map<Product, Integer> productsAndQuantity) {
		this.productsAndQuantity = productsAndQuantity;
	}	

	public BigDecimal getSavedAmount() {
		return savedAmount;
	}

	public void setSavedAmount(BigDecimal savedAmount) {
		this.savedAmount = savedAmount;
	}

	/*
	 * public List<Product> getProducts() { return products; }
	 * 
	 * public void setProducts(List<Product> products) { this.products =
	 * products; }
	 */

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}

	public Set<Offer> getAppliedOffers() {
		return appliedOffers;
	}


	public void setAppliedOffers(Set<Offer> appliedOffers) {
		this.appliedOffers = appliedOffers;
	}



}
