package com.bjss.com.bjss.pricing;

public enum MeasurmentUnit {
	TIN, LOAF, BOTTLE, BAG
}
