package com.bjss.com.bjss.pricing.offers;

import java.math.BigDecimal;

import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Offer;
import com.bjss.com.bjss.pricing.pojos.Product;

public class PercentageOffer extends Offer {

	BigDecimal percentageInFraction;
	Product product;

	public BigDecimal getPercentageInFraction() {
		return percentageInFraction;
	}

	public void setPercentageInFraction(BigDecimal percentageInFraction) {
		this.percentageInFraction = percentageInFraction;
	}

	public PercentageOffer(BigDecimal percentage, Product product, String description) {
		super(description);
		this.percentageInFraction = percentage;
		this.product = product;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

/*	public BigDecimal getDicsountedPrice(BigDecimal originalPrice) {
		return originalPrice.multiply(percentageInFraction);
	}*/

	@Override
	public void applyThisOffer(Basket basket) {	
		for(Product productFromBasket:basket.getProductsAndQuantity().keySet()){
			if(this.product.getName().equals(productFromBasket.getName())){
				BigDecimal discount = productFromBasket.getPrice().subtract(productFromBasket.getPrice().multiply(percentageInFraction));
				BigDecimal quantity = new BigDecimal(basket.getProductsAndQuantity().get(productFromBasket));
				basket.setSavedAmount(basket.getSavedAmount().add(discount).multiply(quantity));
				basket.getAppliedOffers().add(this);
			}
		}
		
	}
}
