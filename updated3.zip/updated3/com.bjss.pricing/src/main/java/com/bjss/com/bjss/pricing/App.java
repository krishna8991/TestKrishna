package com.bjss.com.bjss.pricing;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Locale;
import java.util.Scanner;

import org.apache.commons.lang.WordUtils;
import org.joda.time.DateTime;

import com.bjss.com.bjss.pricing.offers.MultiBuyPercentageOfferOnDifferetProduct;
import com.bjss.com.bjss.pricing.offers.PercentageOffer;
import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Offer;
import com.bjss.com.bjss.pricing.pojos.Product;
import com.bjss.com.bjss.pricing.processors.BasketSubTotalCalculator;
import com.bjss.com.bjss.pricing.processors.BasketTotalCalculator;
import com.bjss.com.bjss.pricing.processors.OffersProcessor;
import com.bjss.com.bjss.pricing.processors.OutputDisplayProcessors;
import com.bjss.com.bjss.pricing.processors.ProductsDetailsProvider;
import com.bjss.com.bjss.pricing.validator.Validator;


public class App {
	
	public static final String ERROR ="Apples, Bread, Soup and Milk are only the available products in stock";

	public static final String PRICE_BASKET = "PriceBasket";
	public static boolean rerun = true;

	static {
		Product apples = new ProductBuilderImpl("Apples").setPrice(new BigDecimal("1.00"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.BAG).create();
		Product bread = new ProductBuilderImpl("Bread").setPrice(new BigDecimal("0.80"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.LOAF).create();
		Product soup = new ProductBuilderImpl("Soup").setPrice(new BigDecimal("0.65"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.TIN).create();
		Product milk = new ProductBuilderImpl("Milk").setPrice(new BigDecimal("1.30"))
				.setCurrency(Currency.getInstance(Locale.UK)).setMeasurmentUnit(MeasurmentUnit.BOTTLE).create();

		Stock.AVAILABLE_PRODUCTS.put(apples.getName(), apples);
		Stock.AVAILABLE_PRODUCTS.put(bread.getName(), bread);
		Stock.AVAILABLE_PRODUCTS.put(soup.getName(), soup);
		Stock.AVAILABLE_PRODUCTS.put(milk.getName(), milk);
		
		
		
		String applesOffer = "Apples have 10% discount off their normal price this week";
		DateTime applesOfferValidFrom = new DateTime(2017, 6, 12, 12, 0, 0, 0);
		DateTime applesOfferValidTo = applesOfferValidFrom.plusDays(7);
		Offer applesPriceDiscount = new PercentageOffer(new BigDecimal(10).divide(new BigDecimal(100)),Stock.AVAILABLE_PRODUCTS.get("Apples"), applesOffer);
		applesPriceDiscount.setValidFrom(applesOfferValidFrom);
		applesPriceDiscount.setValidTo(applesOfferValidTo);
		String soupAndBreadOffer= "Buy 2 tin of soup and get a loaf of bread for half price";
		Offer multiSoupBuyBreadOffer= new MultiBuyPercentageOfferOnDifferetProduct(new BigDecimal(50).divide(new BigDecimal(100)),  Stock.AVAILABLE_PRODUCTS.get("Soup"), Stock.AVAILABLE_PRODUCTS.get("Bread"), 2, 1, soupAndBreadOffer);
		
		AvailableOffers.OFFERS.add(applesPriceDiscount);
		AvailableOffers.OFFERS.add(multiSoupBuyBreadOffer);		
	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		while (rerun) {
			System.out.print(PRICE_BASKET);

			String combinedItems = scanner.nextLine().trim();

			if (combinedItems.length() == 0) {
				rerun = false;
			} else {

				processBasket(combinedItems);
				
			}

		}

		scanner.close();
	
	}

	private static void processBasket(String combinedItems){
		
		String [] items = WordUtils.capitalizeFully(combinedItems).split(("\\s+"));
		Validator validator = new Validator();
		ProductsDetailsProvider productsDetailsProvider= new ProductsDetailsProvider();
		BasketSubTotalCalculator basketSubTotalCalculator = new BasketSubTotalCalculator();
		OffersProcessor offersProcessor= new OffersProcessor();
		BasketTotalCalculator basketTotalCalculator = new BasketTotalCalculator();
		OutputDisplayProcessors outputDisplayProcessors = new OutputDisplayProcessors();
		Basket basket;
		if(validator.validate(items)){
			basket = new Basket(items);
			productsDetailsProvider.processRequest(basket);
			basketSubTotalCalculator.processRequest(basket);
			offersProcessor.processRequest(basket);
			basketTotalCalculator.processRequest(basket);
			outputDisplayProcessors.processRequest(basket);
			
			//System.out.println(basket.getTotal());
			
			
		} else {
			throw new IllegalArgumentException(ERROR);
		}
		
	
	}

}
