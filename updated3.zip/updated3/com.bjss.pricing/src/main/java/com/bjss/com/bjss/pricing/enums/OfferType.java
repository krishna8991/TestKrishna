package com.bjss.com.bjss.pricing.enums;

public enum OfferType {
	PERCENTAGE_DISCOUNT, MULTI_BUY_DEAL //, FIXED_DISCOUNT
}
