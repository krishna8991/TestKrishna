package com.bjss.com.bjss.pricing;

public class OfferStrategy {
	
	//Used for discount and Mutli-buy strategy. Method would be apply offer. And the parameters would be basket.

}
