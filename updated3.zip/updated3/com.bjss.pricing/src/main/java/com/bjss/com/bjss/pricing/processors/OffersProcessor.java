package com.bjss.com.bjss.pricing.processors;

import com.bjss.com.bjss.pricing.AvailableOffers;
import com.bjss.com.bjss.pricing.pojos.Basket;
import com.bjss.com.bjss.pricing.pojos.Offer;

public class OffersProcessor extends BasketProcessor {

	@Override
	public void processRequest(Basket basket) {
	
		for(Offer offer:AvailableOffers.OFFERS){
			offer.applyThisOffer(basket);
		}
	
	}

}
