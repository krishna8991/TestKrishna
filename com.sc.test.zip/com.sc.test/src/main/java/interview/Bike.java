package interview;

/*
 * Andyr request want to hire bikes too 
 */

//Is a relationship doesn't exist here

public class Bike extends Car {
	public int cc;

	public Bike(String reg) {
		super(reg);
	}
	
}
