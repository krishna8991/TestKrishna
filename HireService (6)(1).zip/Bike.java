package interview;

/*
 * Andyr request want to hire bikes too 
 */
public class Bike extends Car {
	public int cc;

	public Bike(String reg) {
		super(reg);
	}
	
}
